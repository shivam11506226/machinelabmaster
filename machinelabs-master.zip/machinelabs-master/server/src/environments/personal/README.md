## What's the deal about this file?

This is just a stub file to have the `personal` directory.
Any file (except this one) placed here will be excluded from version control.
This is the perfect file to place your custom environment files.

Even better, just pass `--env=dev` and both the `environments`, and the `environments/personal` directory will be checked for the existence of an
`environment.dev.ts` file. If it exists in both places, the one in `environment/personal` will be used.