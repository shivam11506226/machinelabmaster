declare module 'ansi-escape-sequences';
