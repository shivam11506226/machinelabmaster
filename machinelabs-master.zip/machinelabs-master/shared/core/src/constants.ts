export const DEFAULT_ENTRY_POINT = 'main.py';

export const DEFAULT_ENTRY_POINT_CONTENT = '';
