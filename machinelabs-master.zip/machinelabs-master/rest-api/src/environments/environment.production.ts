export const environment = {
  firebaseConfig: {
    storageBucket: 'machinelabs-production.appspot.com'
  }
};
