export const environment = {
  firebaseConfig: {
    storageBucket: 'machinelabs-a73cd.appspot.com'
  }
};
