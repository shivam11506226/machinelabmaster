// DO NOT EDIT. COPY FROM @machinelabs/models instead

import { LabDirectory } from './directory';

export interface Lab {
  id: string;
  directory: LabDirectory;
}
