export enum UploadType {
  ExecutionOutput = 'execution_output',
  Other = 'other'
}
