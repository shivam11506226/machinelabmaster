export const AUTH_SERVICE_STUB = {
  requireAuth: () => {},
  requireAuthOnce: () => {},
  linkOrSignInWithGitHub: () => {}
};
