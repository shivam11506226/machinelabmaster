export const ROUTER_STUB = {
  navigate: args => {},
  navigateByUrl: str => {}
};

export const ACTIVATED_ROUTE_STUB = {
  snapShot: {},
  params: {},
  data: {}
};
