export const isImage = fileName => /\.(gif|jpg|jpeg|tiff|png)$/i.test(fileName);
