import { Component } from '@angular/core';

@Component({
  selector: 'ml-console',
  templateUrl: './console.component.html',
  styleUrls: ['./console.component.scss']
})
export class ConsoleComponent {}
