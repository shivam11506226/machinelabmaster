import { HandshakeComponent } from './handshake.component';

export const HANDSHAKE_ROUTES = [
  {
    path: '',
    component: HandshakeComponent
  }
];
