import { InjectionToken } from '@angular/core';
import { ScrollStrategy, Overlay, BlockScrollStrategy } from '@angular/cdk/overlay';

export const FILE_PREVIEW_DIALOG_DATA = new InjectionToken<any>('MlFilePreviewData');
