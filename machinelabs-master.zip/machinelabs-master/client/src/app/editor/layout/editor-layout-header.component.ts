import { Component } from '@angular/core';

@Component({
  selector: 'ml-editor-layout-header',
  template: '<ng-content></ng-content>'
})
export class EditorLayoutHeaderComponent {}
