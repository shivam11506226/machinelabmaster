export class PublicLabConfiguration {
  dockerImageId: string;
}
