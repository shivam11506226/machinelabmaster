export const environment = {
  production: false,
  offline: false,
  testing: true,
  restApiURL: 'https://rest-staging.machinelabs.ai',
  firebaseConfig: {
    apiKey: 'AIzaSyDD0Q23LRt-GWK62WgagF0Px5baznRHSRw',
    authDomain: 'machinelabs-database-testing.firebaseapp.com',
    databaseURL: 'https://machinelabs-database-testing.firebaseio.com',
    projectId: 'machinelabs-database-testing',
    storageBucket: 'machinelabs-database-testing.appspot.com',
    messagingSenderId: '121012318422'
  },
  topPicksLabIds: []
};
