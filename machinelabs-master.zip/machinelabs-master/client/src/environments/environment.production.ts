export const environment = {
  production: true,
  offline: false,
  testing: false,
  restApiURL: 'https://rest.machinelabs.ai',
  firebaseConfig: {
    apiKey: 'AIzaSyDB6mmk8CDyy9D6DpYQgzLd3-wwY5WDSEc',
    authDomain: 'machinelabs-production.firebaseapp.com',
    databaseURL: 'https://machinelabs-production.firebaseio.com',
    projectId: 'machinelabs-production',
    storageBucket: 'machinelabs-production.appspot.com',
    messagingSenderId: '273257478502'
  },
  topPicksLabIds: ['ryGF9Mxgz', 'ByCErAGlz', 'r1JhQGJDb']
};
