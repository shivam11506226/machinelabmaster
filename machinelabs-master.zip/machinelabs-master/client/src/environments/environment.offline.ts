export const environment = {
  production: false,
  offline: true,
  testing: false,
  firebaseConfig: {
    databaseURL: 'ws://127.0.1:52100'
  }
};
