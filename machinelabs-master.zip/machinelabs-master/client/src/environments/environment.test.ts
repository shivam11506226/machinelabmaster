export const environment = {
  production: false,
  offline: false,
  testing: false,
  firebaseConfig: {
    apiKey: 'AIzaSyDegzorhSxWcXV7Nl1bf-mIjGRgGb5dCCY',
    authDomain: 'machinelabs-test.firebaseapp.com',
    databaseURL: 'https://machinelabs-test.firebaseio.com',
    storageBucket: 'machinelabs-test.appspot.com',
    messagingSenderId: '219672978749'
  },
  topPicksLabIds: []
};
